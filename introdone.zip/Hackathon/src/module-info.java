/**
 * 
 */
/**
 * @author charq
 *
 */
module Hackathon {
	requires java.desktop;
}